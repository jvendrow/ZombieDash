#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include <string>
#include "Actor.h"
#include <list>

class Actor;
class Penelope;

using namespace std;

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:
    StudentWorld(std::string assetPath);
    virtual int init();
    virtual int move();
    virtual void cleanUp();
    ~StudentWorld();
    
    bool hasWall(int x, int y);
    bool checkForCitizens(const int x, const int y);
private:
    Penelope* p;
    list<Actor*> li;
};

#endif // STUDENTWORLD_H_
