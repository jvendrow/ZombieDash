#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "StudentWorld.h"
#include <list>

class StudentWorld;
using namespace std;

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp


class Actor: public GraphObject
{
public:
    Actor(int imageID, double startX, double startY, Direction dir = 0, int depth = 0, double size = 1.0, StudentWorld* game_world = nullptr);
    virtual void doSomething() = 0;
    virtual bool isWall() const {return false;};
    virtual bool isCitizen() const {return false;};
    virtual bool isPenelope() const {return false;};
    virtual bool isPerson() const {return false;};
    virtual bool isZombie() const {return false;};
    
    StudentWorld* getWorld() const;

private:
    bool isAlive;
    StudentWorld* world;
    

};

class MovingThing: public Actor
{
public:
    MovingThing(int imageID, double startX, double startY, Direction dir = 0, int depth = 0, double size = 1.0, StudentWorld* game_world = nullptr);
    virtual void doSomething() = 0;
    //void addOther(Actor* a); //Adds objects that Penelope should not hit
    //bool intersects(int x, int y);
private:
    //list<Actor*> others;
};

class Person: public MovingThing
{
public:
    Person(int imageID, double startX, double startY, Direction dir = 0, int depth = 0, double size = 1.0, StudentWorld* game_world = nullptr);
    virtual void doSomething() = 0;
    
};

class Penelope: public Person
{
public:
    Penelope(int imageID, double startX, double startY, Direction dir = 0, int depth = 0, double size = 1.0, StudentWorld* game_world = nullptr);
    virtual void doSomething();
    //StudentWorld* getWorld() const;
    virtual bool isPenelope() const {return true;};
    
private:
    //StudentWorld* world;
};

class Citizen: public Person
{
public:
    virtual bool isCitizen() const {return true;};

};

class Zombie: public MovingThing
{
public:

};

class SmartZombie: public Zombie
{
public:
    
private:
    bool in_paralysis;
};

class DumbZombie: public Zombie
{
public:
    
};

class Damager: public Actor
{
public:
    Damager(int imageID, double startX, double startY, Direction dir = 0, int depth = 0, double size = 1.0, StudentWorld* game_world = nullptr);
    
};

class Landmine: public Damager
{
public:
    Landmine(int imageID, double startX, double startY, Direction dir = 0, int depth = 0, double size = 1.0, StudentWorld* game_world = nullptr);

    
};

class Pit: public Damager
{
public:
    Pit(int imageID, double startX, double startY, Direction dir = 0, int depth = 0, double size = 1.0, StudentWorld* game_world = nullptr);

    
};

class Flame: public Damager
{
public:
    Flame(int imageID, double startX, double startY, Direction dir = 0, int depth = 0, double size = 1.0, StudentWorld* game_world = nullptr);

    
};

class Vomit: public Damager
{
public:
    Vomit(int imageID, double startX, double startY, Direction dir = 0, int depth = 0, double size = 1.0, StudentWorld* game_world = nullptr);

    
};

class Goodie: public Actor
{
public:
    Goodie(int imageID, double startX, double startY, Direction dir = 0, int depth = 0, double size = 1.0, StudentWorld* game_world = nullptr);

};

class VaccineGoodie: public Goodie
{
public:
    VaccineGoodie(int imageID, double startX, double startY, Direction dir = 0, int depth = 0, double size = 1.0, StudentWorld* game_world = nullptr);

};

class GasCanGoodie: public Goodie
{
public:
    GasCanGoodie(int imageID, double startX, double startY, Direction dir = 0, int depth = 0, double size = 1.0, StudentWorld* game_world = nullptr);

    
};

class LandmineGoodie: public Goodie
{
public:
    LandmineGoodie(int imageID, double startX, double startY, Direction dir = 0, int depth = 0, double size = 1.0, StudentWorld* game_world = nullptr);

    
};

class Externality: public Actor
{
public:
    Externality(int imageID, double startX, double startY, Direction dir = 0, int depth = 0, double size = 1.0, StudentWorld* game_world = nullptr);
    virtual void doSomething() = 0;
    
};

class Wall: public Externality
{
public:
    Wall(int imageID, double startX, double startY, Direction dir = 0, int depth = 0, double size = 1.0, StudentWorld* game_world = nullptr);
    virtual void doSomething() {};
    bool isWall() const {return true;};

    
};

class Exit: public Externality
{
public:
    Exit(int imageID, double startX, double startY, Direction dir = 0, int depth = 1, double size = 1.0, StudentWorld* game_world = nullptr);
    bool isFinished() {return finished;};
    void doSomething();
private:
    bool finished;
    
};

#endif // ACTOR_H_


