#include "StudentWorld.h"
#include "GameConstants.h"
#include <string>
#include "Level.h"

using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath), p(nullptr)
{}

int StudentWorld::init()
{
    
    p = new Penelope(IID_PLAYER, 0, 0, 0, 0, 1, this);

    Level lev(assetPath());
    string levelFile = "level01.txt";
    Level::LoadResult result = lev.loadLevel(levelFile);
    if (result == Level::load_fail_file_not_found)
        cerr << "Cannot find level01.txt data file" << endl;
    else if (result == Level::load_fail_bad_format)
        cerr << "Your level was improperly formatted" << endl;
    else if (result == Level::load_success)
    {
        cerr << "Successfully loaded level" << endl;
        //Level::MazeEntry ge = lev.getContentsOf(5,10); // level_x=5, level_y=10
        for(int i = 0; i < LEVEL_WIDTH; i++) {
            for(int j = 0; j < LEVEL_HEIGHT; j++) {
                Level::MazeEntry ge = lev.getContentsOf(i,j); // level_x=5, level_y=10
                switch (ge) // so x=80 and y=160
                {
                    case Level::empty:
                        break;
                    case Level::smart_zombie:
                        //cout << "Location 80,160 starts with a smart zombie" << endl;
                        break;
                    case Level::dumb_zombie:
                        //cout << "Location 80,160 starts with a dumb zombie" << endl;
                        break;
                    case Level::player:
                        p->moveTo(i*SPRITE_WIDTH, j*SPRITE_HEIGHT);
                        cout << "Location 80,160 is where Penelope starts" << endl;
                        break;
                    case Level::exit:
                        li.push_front(new Exit(IID_EXIT, i*SPRITE_WIDTH, j*SPRITE_HEIGHT, 0, 1, 1, this));
                        //cout << "Location 80,160 is where an exit is" << endl;
                        break;
                    case Level::wall:
                        //Actor* a = new Wall(IID_WALL, i*SPRITE_WIDTH, j*SPRITE_HEIGHT, 0, 0);
                        li.push_front(new Wall(IID_WALL, i*SPRITE_WIDTH, j*SPRITE_HEIGHT, 0, 0));
                        //p->addOther(li.back());
                        //cout << "Location 80,160 holds a Wall" << endl;
                        break;
                    case Level::pit:
                        //cout << "Location 80,160 has a pit in the ground" << endl;
                        break;
                    default:
                        break;
                }
            }
        }
    }
    
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    // This code is here merely to allow the game to build, run, and terminate after you hit enter.
    // Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
    //decLives();
    p->doSomething();
    for(list<Actor*>::iterator p = li.begin(); p != li.end(); p++) {
        cout << (*p) << endl;
        (*p)->doSomething();
    }
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    delete p;
    for(auto itr = li.begin(); itr != li.end(); itr++)
    {
        Actor* a = *itr;
        delete a;
    }
    //while(li.size() > 0) {
    //    Actor* a = li.back();
    //    li.pop_back();
    //    delete a;
    //}
    //li.clear();
}

StudentWorld::~StudentWorld()
{
    cleanUp();
}

bool StudentWorld::hasWall(int x, int y) {
    for(list<Actor*>::iterator p = li.begin(); p != li.end(); p++) {
        //cout << "sex" << endl;
        if((*p)->isWall() && abs((*p)->getX() - x) < SPRITE_WIDTH && abs((*p)->getY() - y) < SPRITE_HEIGHT) {
            return true;
        }
    }
    return false;
    
}

bool StudentWorld::checkForCitizens(const int x, const int y) {
    bool no_citizens = true;
    for(list<Actor*>::iterator p = li.begin(); p != li.end(); p++) {
        if((*p)->isCitizen()) {
            no_citizens = false;
            if(abs((*p)->getX() - x) < SPRITE_WIDTH && abs((*p)->getY() - y) < SPRITE_HEIGHT) {
                //set Citizen to dead
            }
        }
    }
    if(no_citizens) {
        if(abs((p)->getX() - x) < SPRITE_WIDTH && abs((p)->getY() - y) < SPRITE_HEIGHT) {
            cleanUp();
            init();
        }
    }
    return true;
}
