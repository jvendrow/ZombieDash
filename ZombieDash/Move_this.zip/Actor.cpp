#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

Actor::Actor(int imageID, double startX, double startY, Direction dir, int depth, double size, StudentWorld* game_world)
:GraphObject(imageID, startX, startY, dir, depth, size), isAlive(true), world(game_world)
{};

StudentWorld* Actor::getWorld() const {
    return world;
}

MovingThing::MovingThing(int imageID, double startX, double startY, Direction dir, int depth, double size, StudentWorld* game_world)
:Actor(imageID, startX, startY, dir, depth, size, game_world)
{};
/*
bool MovingThing::intersects(int x, int y) {
    for(list<Actor*>::iterator p = others.begin(); p != others.end(); p++) {
        if(abs((*p)->getX() - x) < SPRITE_WIDTH && abs((*p)->getY() - y) < SPRITE_HEIGHT) {
            return true;
        }
    }
    return false;
}

void MovingThing::addOther(Actor* a) {
    others.push_back(a);
}
*/
Person::Person(int imageID, double startX, double startY, Direction dir, int depth, double size, StudentWorld* game_world)
:MovingThing(imageID, startX, startY, dir, depth, size, game_world)
{};

Penelope::Penelope(int imageID, double startX, double startY, Direction dir, int depth, double size, StudentWorld* game_world)
:Person(imageID, startX, startY, dir, depth, size, game_world)
{};

void Penelope::doSomething() {
    int ch;
    if (getWorld()->getKey(ch))
    {
        int newx;
        int newy;
        // user hit a key during this tick!
        switch (ch)
        {
            case KEY_PRESS_LEFT:
                newx = getX() - 4;
                newy = getY();
                setDirection(180);
               // if(!getWorld()->hasWall(newx, newy)) {
                    moveTo(newx, newy);
                //}
                
                break;
            case KEY_PRESS_RIGHT:
                newx = getX() + 4;
                newy = getY();
                setDirection(0);
                if(!getWorld()->hasWall(newx, newy)) {
                    moveTo(newx, newy);
                }
                break;
            case KEY_PRESS_UP:
                newx = getX();
                newy = getY() + 4;
                setDirection(90);
                if(!getWorld()->hasWall(newx, newy)) {
                    moveTo(newx, newy);
                }
                break;
            case KEY_PRESS_DOWN:
                newx = getX();
                newy = getY() - 4;
                setDirection(270);
                if(!getWorld()->hasWall(newx, newy)) {
                    moveTo(newx, newy);
                }
                break;
            case KEY_PRESS_SPACE:
                //... add flames in front of Penelope...;
                break;
                // etc…
        }
    }
}


Damager::Damager(int imageID, double startX, double startY, Direction dir, int depth, double size, StudentWorld* game_world)
:Actor(imageID, startX, startY, dir, depth, size, game_world)
{};

Landmine::Landmine(int imageID, double startX, double startY, Direction dir, int depth, double size, StudentWorld* game_world)
:Damager(imageID, startX, startY, dir, depth, size, game_world)
{};

Pit::Pit(int imageID, double startX, double startY, Direction dir, int depth, double size, StudentWorld* game_world)
:Damager(imageID, startX, startY, dir, depth, size, game_world)
{};

Flame::Flame(int imageID, double startX, double startY, Direction dir, int depth, double size, StudentWorld* game_world)
:Damager(imageID, startX, startY, dir, depth, size, game_world)
{};

Vomit::Vomit(int imageID, double startX, double startY, Direction dir, int depth, double size, StudentWorld* game_world)
:Damager(imageID, startX, startY, dir, depth, size, game_world)
{};

Goodie::Goodie(int imageID, double startX, double startY, Direction dir, int depth, double size, StudentWorld* game_world)
:Actor(imageID, startX, startY, dir, depth, size, game_world)
{};

VaccineGoodie::VaccineGoodie(int imageID, double startX, double startY, Direction dir, int depth, double size, StudentWorld* game_world)
:Goodie(imageID, startX, startY, dir, depth, size, game_world)
{};

GasCanGoodie::GasCanGoodie(int imageID, double startX, double startY, Direction dir, int depth, double size, StudentWorld* game_world)
:Goodie(imageID, startX, startY, dir, depth, size, game_world)
{};

LandmineGoodie::LandmineGoodie(int imageID, double startX, double startY, Direction dir, int depth, double size, StudentWorld* game_world)
:Goodie(imageID, startX, startY, dir, depth, size, game_world)
{};


Externality::Externality(int imageID, double startX, double startY, Direction dir, int depth, double size, StudentWorld* game_world)
:Actor(imageID, startX, startY, dir, depth, size, game_world)
{};

Wall::Wall(int imageID, double startX, double startY, Direction dir, int depth, double size, StudentWorld* game_world)
:Externality(imageID, startX, startY, dir, depth, size, game_world)
{};

Exit::Exit(int imageID, double startX, double startY, Direction dir, int depth, double size, StudentWorld* game_world)
:Externality(imageID, startX, startY, dir, depth, size, game_world)
{};

void Exit::doSomething() {
    getWorld()->checkForCitizens(getX(), getY());
}


